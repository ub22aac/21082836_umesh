import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class Main_runnerTest {
    Main_runner run1;
    public Main_runnerTest() {
    }
    @BeforeEach
    public void setUp() {
        run1 = new Main_runner();
    }
    @AfterEach
    public void tearDown() {
        run1 = null;
    }
    
    @Test
    public void testAmountYoga() {
        Main_runner mainrunner = new Main_runner();
        int expected = 70;
        int result = mainrunner.amount("YOGA");
        assertEquals(expected, result);
    }
    
    @Test
    public void testAmountSpin() {
        Main_runner mainrunner = new Main_runner();
        int expected = 100;
        int result = mainrunner.amount("SPIN");
        assertEquals(expected, result);
    }
    
    @Test
    public void testAmountBodySculpt() {
        Main_runner mainrunner = new Main_runner();
        int expected = 90;
        int result = mainrunner.amount("BODY SCULPT");
        assertEquals(expected, result);
    }
    
    @Test
    public void testAmountZumba() {
        Main_runner mainrunner = new Main_runner();
        int expected = 50;
        int result = mainrunner.amount("ZUMBA");
        assertEquals(expected, result);
    }
    
    @Test
    public void testAmountInvalidExercise() {
        Main_runner mainrunner = new Main_runner();
        int expected = 0;
        int result = mainrunner.amount("INVALID");
        assertEquals(expected, result);
    }
}
