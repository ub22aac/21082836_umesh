public class Booking_Types extends javax.swing.JFrame {
    public Booking_Types() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        main = new javax.swing.JLabel();
        book_day = new javax.swing.JButton();
        book_ex = new javax.swing.JButton();

        jButton2.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        jButton2.setText("2. Sunday Schedules");

        jButton3.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        jButton3.setText("2. Book By FitnessType");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        main.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        main.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        main.setText("Appointment Types");

        book_day.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        book_day.setText("1. By Days");
        book_day.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book_dayActionPerformed(evt);
            }
        });

        book_ex.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        book_ex.setText("2. By Lessons");
        book_ex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book_exActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(102, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(book_day, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(book_ex, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main)
                .addGap(40, 40, 40)
                .addComponent(book_day)
                .addGap(40, 40, 40)
                .addComponent(book_ex)
                .addGap(0, 40, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void book_dayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book_dayActionPerformed
        By_days bpd = new By_days();
        bpd.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_book_dayActionPerformed

    private void book_exActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book_exActionPerformed
        By_Fitness_tpes bbft = new By_Fitness_tpes();
        bbft.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_book_exActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Booking_Types().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton book_day;
    private javax.swing.JButton book_ex;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel main;
    // End of variables declaration//GEN-END:variables
}
