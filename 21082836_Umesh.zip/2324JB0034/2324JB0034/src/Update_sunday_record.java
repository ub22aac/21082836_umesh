import javax.swing.JOptionPane;
public class Update_sunday_record extends javax.swing.JFrame {
    public Update_sunday_record() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        id_t = new javax.swing.JTextField();
        exercise_t = new javax.swing.JComboBox<>();
        idl = new javax.swing.JLabel();
        ok = new javax.swing.JButton();
        mobile_t = new javax.swing.JTextField();
        address_t = new javax.swing.JTextField();
        main_heading = new javax.swing.JLabel();
        age_t = new javax.swing.JTextField();
        name = new javax.swing.JLabel();
        addresss = new javax.swing.JLabel();
        Age = new javax.swing.JLabel();
        name_t = new javax.swing.JTextField();
        mobile = new javax.swing.JLabel();
        timel = new javax.swing.JLabel();
        time_t = new javax.swing.JComboBox<>();
        exercise = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        id_t.setEditable(false);
        id_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        exercise_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        exercise_t.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---Select---", "SPIN", "ZUMBA" }));
        exercise_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exercise_tActionPerformed(evt);
            }
        });

        idl.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        idl.setText("1. ID       :");

        ok.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        ok.setText("OK");
        ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okActionPerformed(evt);
            }
        });

        mobile_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        address_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        main_heading.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        main_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        main_heading.setText("Update Saturday Record");

        age_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        name.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        name.setText("2. Name     :");

        addresss.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        addresss.setText("5. Address  :");

        Age.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        Age.setText("3. Age      :");

        name_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        name_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_tActionPerformed(evt);
            }
        });

        mobile.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        mobile.setText("4. Mobile   :");

        timel.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        timel.setText("7. Timing   :");

        time_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        time_t.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---Select---", "Morning", "Afternoon", "Evening" }));

        exercise.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        exercise.setText("6. Exercise :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_heading, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(exercise)
                                .addGap(50, 50, 50)
                                .addComponent(exercise_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(idl)
                                    .addComponent(timel)
                                    .addComponent(addresss)
                                    .addComponent(mobile)
                                    .addComponent(Age)
                                    .addComponent(name))
                                .addGap(50, 50, 50)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(id_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(name_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(age_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(mobile_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(address_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(time_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(129, 129, 129)
                        .addComponent(ok, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main_heading, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idl)
                    .addComponent(id_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name)
                    .addComponent(name_t, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Age)
                    .addComponent(age_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mobile)
                    .addComponent(mobile_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addresss)
                    .addComponent(address_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exercise)
                    .addComponent(exercise_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timel)
                    .addComponent(time_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(ok)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void update_values_sunday(String send[])
    {
        id_t.setText(send[0]);
        name_t.setText(send[1]);
        age_t.setText(send[2]);
        mobile_t.setText(send[3]);
        address_t.setText(send[4]);
        exercise_t.setSelectedItem(String.valueOf(send[5]));
        time_t.setSelectedItem(String.valueOf(send[6]));
    }
    
    private void exercise_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exercise_tActionPerformed

    }//GEN-LAST:event_exercise_tActionPerformed

    private void okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okActionPerformed
        String[] temp = new String[8];
        temp[0]=id_t.getText().trim();
        temp[1]=name_t.getText().trim();
        temp[2]=age_t.getText().trim();
        temp[3]=mobile_t.getText().trim();
        temp[4]=address_t.getText().trim();
        temp[5]=String.valueOf(exercise_t.getSelectedItem()).trim();
        temp[6]= String.valueOf(time_t.getSelectedItem()).trim();
        temp[7]="Saturday";

        if(id_t.getText().equals("") || age_t.getText().equals("") || mobile_t.getText().equals("") || address_t.getText().equals("") || String.valueOf(exercise_t.getSelectedItem()).equals("Select") || String.valueOf(time_t.getSelectedItem()).equals("Select"))
        {
            JOptionPane.showMessageDialog(this,"Something Went Wrong Please Fill all Fields","Alert",JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            try
            {
                if(Integer.parseInt(age_t.getText().trim())>0 && temp[3].length() == 10 )
                {
                    if(temp[3].length() == 10)
                    {
                        sunday sd = new sunday();
                        sd.set_update_values_6(temp);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(this,"Please Enter Proper Mobile Number","Alert",JOptionPane.WARNING_MESSAGE);
                        this.mobile_t.setText("");
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(this,"Please Enter correct data in Mobile & age","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
            catch(Exception obj)
            {
                JOptionPane.showMessageDialog(this,"There is an Problem in your inserted data So pease feed correct data","Alert",JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_okActionPerformed

    private void name_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_tActionPerformed

    }//GEN-LAST:event_name_tActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Update_sunday_record().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Age;
    private javax.swing.JTextField address_t;
    private javax.swing.JLabel addresss;
    private javax.swing.JTextField age_t;
    private javax.swing.JLabel exercise;
    private javax.swing.JComboBox<String> exercise_t;
    private javax.swing.JTextField id_t;
    private javax.swing.JLabel idl;
    private javax.swing.JLabel main_heading;
    private javax.swing.JLabel mobile;
    private javax.swing.JTextField mobile_t;
    private javax.swing.JLabel name;
    private javax.swing.JTextField name_t;
    private javax.swing.JButton ok;
    private javax.swing.JComboBox<String> time_t;
    private javax.swing.JLabel timel;
    // End of variables declaration//GEN-END:variables
}
