import javax.swing.JOptionPane;
public class Exercise_4 extends javax.swing.JFrame {
    static String[][] zumba_array = new String[5][8];
    static int m=0;
    public Exercise_4() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cancel = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        ok = new javax.swing.JButton();
        name = new javax.swing.JLabel();
        Age = new javax.swing.JLabel();
        name_t = new javax.swing.JTextField();
        mobile = new javax.swing.JLabel();
        exercise_t = new javax.swing.JTextField();
        timel = new javax.swing.JLabel();
        time_t = new javax.swing.JComboBox<>();
        exercisel = new javax.swing.JLabel();
        id_t = new javax.swing.JTextField();
        idl = new javax.swing.JLabel();
        mobile_t = new javax.swing.JTextField();
        address_t = new javax.swing.JTextField();
        age_t = new javax.swing.JTextField();
        addresss = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
            	formWindowClosing(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });

        cancel.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Zumba Appointment");

        ok.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        ok.setText("OK");
        ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okActionPerformed(evt);
            }
        });

        name.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        name.setText("2. Name     :");

        Age.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        Age.setText("3. Age      :");

        name_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        name_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_tActionPerformed(evt);
            }
        });

        mobile.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        mobile.setText("4. Mobile   :");

        exercise_t.setEditable(false);
        exercise_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        exercise_t.setText("ZUMBA");
        exercise_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exercise_tActionPerformed(evt);
            }
        });

        timel.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        timel.setText("7. Timing   :");

        time_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        time_t.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---Select---", "Morning", "Afternoon", "Evening" }));

        exercisel.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        exercisel.setText("6. Exercise :");

        id_t.setEditable(false);
        id_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        idl.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        idl.setText("1. ID       :");

        mobile_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        address_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        age_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        addresss.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        addresss.setText("5. Address  :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ok)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cancel)
                        .addGap(136, 136, 136))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(idl)
                            .addComponent(timel)
                            .addComponent(exercisel)
                            .addComponent(addresss)
                            .addComponent(mobile)
                            .addComponent(Age)
                            .addComponent(name))
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(id_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(name_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(age_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(mobile_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(address_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(exercise_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(time_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 70, Short.MAX_VALUE))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idl)
                    .addComponent(id_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name)
                    .addComponent(name_t, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Age)
                    .addComponent(age_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mobile)
                    .addComponent(mobile_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addresss)
                    .addComponent(address_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exercisel)
                    .addComponent(exercise_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timel)
                    .addComponent(time_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ok)
                    .addComponent(cancel))
                .addGap(30, 30, 30))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
// -------- Delete Bookings --------------------------------
    public void set_dlt_4(String vlu)
    {
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(zumba_array[z1][0].equals(vlu))
                {
                    m=z1;
                    zumba_array[z1][0]="";
                    zumba_array[z1][1]="";
                    zumba_array[z1][2]="";
                    zumba_array[z1][3]="";
                    zumba_array[z1][4]="";
                    zumba_array[z1][5]="";
                    zumba_array[z1][6]="";
                    zumba_array[z1][7]="";
                    jj=true;
                    break;
                }
                else
                {
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"False");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Your Slot delete Successfully");
        }
    }
    


// --------show Bookings --------------------------------
    public void set_4(String vlu1)
    {
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(zumba_array[z1][0].equals(vlu1))
                {
                    JOptionPane.showMessageDialog(this,"ID     : "+this.zumba_array[z1][0]+"\n\nName     : "+this.zumba_array[z1][1]+"\n\nAge      : "+this.zumba_array[(z1)][2]+"\n\nMobile   : "+this.zumba_array[(z1)][3]+"\n\nAddress  : "+this.zumba_array[z1][4]+"\n\nExercise : "+this.zumba_array[z1][5]+"\n\nDay      : "+this.zumba_array[z1][6]+"\n\nTiming      : "+this.zumba_array[(z1)][7]+"\n\n");
                    jj=true;
                    break;
                }
                else
                {
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"No Slot Available on this ID");
        }
    }
    


// -------- set Update values --------------------------------
    public void set_update_values_4(String temp[])
    {
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(zumba_array[z1][0].equals(temp[0]))
                {
                    jj=true;
                    this.zumba_array[z1][0]=temp[0];
                    this.zumba_array[z1][1]=temp[1];
                    this.zumba_array[z1][2]=temp[2];
                    this.zumba_array[z1][3]=temp[3];
                    this.zumba_array[z1][4]=temp[4];
                    this.zumba_array[z1][5]=temp[5];
                    this.zumba_array[z1][6]=temp[6];
                    this.zumba_array[z1][7]=temp[7];
                    break;
                }
                else
                {   
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"No Slot Available on this ID");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Data Updated successfully");
        }
    }


// -------- Set Changes --------------------------------
    public void set_change_4(String vlu)
    {
        String[] send = new String[8];
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(zumba_array[z1][0].equals(vlu))
                {
                    jj=true;
                    send[0]=vlu;
                    send[1]=this.zumba_array[z1][1];
                    send[2]=this.zumba_array[z1][2];
                    send[3]=this.zumba_array[z1][3];
                    send[4]=this.zumba_array[z1][4];
                    send[5]=this.zumba_array[z1][5];
                    send[6]=this.zumba_array[z1][6];
                    send[7]=this.zumba_array[z1][7];                    
                    Update_record up= new Update_record();
                    up.setVisible(true);
                    up.update_values_1(send);
                    break;
                }
                else
                {   
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"No Slot Available on this ID");
        }
    }
    
    
    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        name_t.setText("");
        age_t.setText("");
        mobile_t.setText("");
        address_t.setText("");
        time_t.setSelectedIndex(0);
    }//GEN-LAST:event_cancelActionPerformed

    private void okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okActionPerformed
        String time,name,age,mobile,address;
        name = name_t.getText().trim();
        age = age_t.getText().trim();
        mobile = this.mobile_t.getText().trim();
        address = this.address_t.getText().trim();
        time = String.valueOf(this.time_t.getSelectedIndex());
        if(name.equals("") || age.equals("") || mobile.equals("") || address.equals(""))
        {
            JOptionPane.showMessageDialog(this,"Something Went Wrong Please Fill all Fields","Alert",JOptionPane.WARNING_MESSAGE);
            this.name_t.setText("");
            this.age_t.setText("");
            this.address_t.setText("");
            this.address_t.setText("");
            time_t.setSelectedIndex(0);
        }
        else
        {
            try
            {
                if(Integer.parseInt(age)>0 && mobile.length() >= 10 )
                {
                    if(mobile.length() >= 10)
                    {
                        this.name_t.setText("");
                        this.age_t.setText("");
                        this.address_t.setText("");
                        this.address_t.setText("");                     
                        time_t.setSelectedIndex(0);
                        if(m<5)
                        {
                            if(zumba_array[m][4] == null || zumba_array[m][4].equals(""))
                            {
                                this.zumba_array[m][0]="Y"+String.valueOf(m);
                                this.zumba_array[m][1]=name;
                                this.zumba_array[m][2]=age;
                                this.zumba_array[m][3]=mobile;
                                this.zumba_array[m][4]=address;
                                this.zumba_array[m][5]="Yoga";
                                this.zumba_array[m][6]=time;
                                this.zumba_array[m][7]="Sunday";
                                JOptionPane.showMessageDialog(this,"Your Slot Booked Successfully");
                            }
                            m++;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(this,"All Slots of Sunday are booked Please Try again later","Alert",JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(this,"Please Enter Proper Mobile Number","Alert",JOptionPane.WARNING_MESSAGE);
                        this.mobile_t.setText("");
                    }
                }
                else
                {
                    this.age_t.setText("");
                    this.mobile_t.setText("");
                    JOptionPane.showMessageDialog(this,"Please Enter correct data in Mobile & age","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
            catch(Exception obj)
            {
                JOptionPane.showMessageDialog(this,"There is an Problem in your inserted data So pease feed correct data","Alert",JOptionPane.WARNING_MESSAGE);
                this.name_t.setText("");
                this.age_t.setText("");
                this.mobile_t.setText("");
                this.address_t.setText("");
                time_t.setSelectedIndex(0);
            }
        }
    }//GEN-LAST:event_okActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
    	 this.id_t.setText(String.valueOf("Z"+String.valueOf(1)));
//        By_Fitness_tpes bbft = new By_Fitness_tpes();
//        bbft.setVisible(true);
    }//GEN-LAST:event_formWindowClosing

    private void name_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_tActionPerformed

    }//GEN-LAST:event_name_tActionPerformed

    private void exercise_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exercise_tActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_exercise_tActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Exercise_4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Age;
    private javax.swing.JTextField address_t;
    private javax.swing.JLabel addresss;
    private javax.swing.JTextField age_t;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField exercise_t;
    private javax.swing.JLabel exercisel;
    private javax.swing.JTextField id_t;
    private javax.swing.JLabel idl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel mobile;
    private javax.swing.JTextField mobile_t;
    private javax.swing.JLabel name;
    private javax.swing.JTextField name_t;
    private javax.swing.JButton ok;
    private javax.swing.JComboBox<String> time_t;
    private javax.swing.JLabel timel;
    // End of variables declaration//GEN-END:variables
}
