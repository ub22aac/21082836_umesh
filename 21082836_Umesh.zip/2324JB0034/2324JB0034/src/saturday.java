import javax.swing.JOptionPane;
public class saturday extends javax.swing.JFrame {

    static String[][] saturday_day_array = new String[5][8];
    static int i = 0;

    public saturday() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        exercise = new javax.swing.JLabel();
        exercise_t = new javax.swing.JComboBox<>();
        ok = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        main_heading = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        Age = new javax.swing.JLabel();
        name_t = new javax.swing.JTextField();
        mobile = new javax.swing.JLabel();
        timel = new javax.swing.JLabel();
        time_t = new javax.swing.JComboBox<>();
        id_t = new javax.swing.JTextField();
        idl = new javax.swing.JLabel();
        mobile_t = new javax.swing.JTextField();
        address_t = new javax.swing.JTextField();
        age_t = new javax.swing.JTextField();
        addresss = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        exercise.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        exercise.setText("6. Exercise :");

        exercise_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        exercise_t.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---Select---", "YOGA", "BODY SCULE" }));
        exercise_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exercise_tActionPerformed(evt);
            }
        });

        ok.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        ok.setText("OK");
        ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okActionPerformed(evt);
            }
        });

        cancel.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        cancel.setText("Cancel");
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });

        main_heading.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        main_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        main_heading.setText("Saturday Appointment");

        name.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        name.setText("2. Name     :");

        Age.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        Age.setText("3. Age      :");

        name_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        name_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_tActionPerformed(evt);
            }
        });

        mobile.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        mobile.setText("4. Mobile   :");

        timel.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        timel.setText("7. Timing   :");

        time_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        time_t.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---Select---", "Morning", "Afternoon", "Evening" }));

        id_t.setEditable(false);
        id_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        idl.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        idl.setText("1. ID       :");

        mobile_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        address_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        age_t.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N

        addresss.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        addresss.setText("5. Address  :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_heading, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(exercise)
                        .addGap(50, 50, 50)
                        .addComponent(exercise_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(idl)
                            .addComponent(timel)
                            .addComponent(addresss)
                            .addComponent(mobile)
                            .addComponent(Age)
                            .addComponent(name))
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(id_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(age_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mobile_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(address_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(time_t, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(ok)
                        .addGap(131, 131, 131)
                        .addComponent(cancel)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main_heading, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idl)
                    .addComponent(id_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name)
                    .addComponent(name_t, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Age)
                    .addComponent(age_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mobile)
                    .addComponent(mobile_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addresss)
                    .addComponent(address_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exercise)
                    .addComponent(exercise_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timel)
                    .addComponent(time_t, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancel)
                    .addComponent(ok))
                .addGap(30, 30, 30))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    // -------- Delete Bookings --------------------------------
    public void set_dlt_5(String vlu)
    {
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(saturday_day_array[z1][0].equals(vlu))
                {
                    i=z1;
                    saturday_day_array[z1][0]="";
                    saturday_day_array[z1][1]="";
                    saturday_day_array[z1][2]="";
                    saturday_day_array[z1][3]="";
                    saturday_day_array[z1][4]="";
                    saturday_day_array[z1][5]="";
                    saturday_day_array[z1][6]="";
                    saturday_day_array[z1][7]="";
                    jj=true;
                    break;
                }
                else
                {
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"False");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Your Slot delete Successfully");
        }
    }
    
    

// --------show Bookings --------------------------------
    public void set_5(String vlu1)
    {
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(saturday_day_array[z1][0].equals(vlu1))
                {
                    JOptionPane.showMessageDialog(this,"ID     : "+this.saturday_day_array[z1][0]+"\n\nName     : "+this.saturday_day_array[z1][1]+"\n\nAge      : "+this.saturday_day_array[(z1)][2]+"\n\nMobile   : "+this.saturday_day_array[(z1)][3]+"\n\nAddress  : "+this.saturday_day_array[z1][4]+"\n\nExercise : "+this.saturday_day_array[z1][5]+"\n\nDay      : "+this.saturday_day_array[z1][7]+"\n\nTiming      : "+this.saturday_day_array[(z1)][6]+"\n\n");
                    jj=true;
                    break;
                }
                else
                {
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"No Slot Available on this ID");
        }
    }
    


// -------- set Update values --------------------------------
    public void set_update_values_5(String temp[])
    {
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(saturday_day_array[z1][0].equals(temp[0]))
                {
                    jj=true;
                    this.saturday_day_array[z1][0]=temp[0];
                    this.saturday_day_array[z1][1]=temp[1];
                    this.saturday_day_array[z1][2]=temp[2];
                    this.saturday_day_array[z1][3]=temp[3];
                    this.saturday_day_array[z1][4]=temp[4];
                    this.saturday_day_array[z1][5]=temp[5];
                    this.saturday_day_array[z1][6]=temp[6];
                    this.saturday_day_array[z1][7]=temp[7];
                    break;
                }
                else
                {   
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"No Slot Available on this ID");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Data Updated successfully");
        }
    }


// -------- Set Changes --------------------------------
    public void set_change_5(String vlu)
    {
        String[] send = new String[8];
        boolean jj = false;
        try{
            for(int z1=0;z1<5;z1++)
            {
                if(saturday_day_array[z1][0].equals(vlu))
                {
                    jj=true;
                    send[0]=vlu;
                    send[1]=this.saturday_day_array[z1][1];
                    send[2]=this.saturday_day_array[z1][2];
                    send[3]=this.saturday_day_array[z1][3];
                    send[4]=this.saturday_day_array[z1][4];
                    send[5]=this.saturday_day_array[z1][5];
                    send[6]=this.saturday_day_array[z1][6];
                    send[7]=this.saturday_day_array[z1][7];                    
                    Update_saturday_record up= new Update_saturday_record();
                    up.setVisible(true);
                    up.update_values_saturday(send);
                    break;
                }
                else
                {   
                    jj=false;
                }
            }            
        }
        catch(Exception obj)
        {
            jj=false;
        }
        if(jj == false)
        {
            JOptionPane.showMessageDialog(this,"No Slot Available on this ID");
        }
    }

    
    
    public void set_dlt_5() {
        Main_runner mr = new Main_runner();
        mr.allinone = 0;
        JOptionPane.showMessageDialog(this, "Your Slot delete Successfully");
    }

    public void set_5(){
        if (i >= 0) {
            JOptionPane.showMessageDialog(this, "Name     : " + this.saturday_day_array[(i - 1)][0] + "\nAge      : " + this.saturday_day_array[(i - 1)][1] + "\nMobile   : " + this.saturday_day_array[(i - 1)][2] + "\nAddress  : " + this.saturday_day_array[(i - 1)][3] + "\nExercise : " + this.saturday_day_array[(i - 1)][4] + "\nDay      : " + this.saturday_day_array[(i - 1)][5] + "\nAmount:      " + this.saturday_day_array[(i - 1)][6]);
        } else {
            JOptionPane.showMessageDialog(this, "There is no slot", "Alert", JOptionPane.WARNING_MESSAGE);
        }
    }
    private void exercise_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exercise_tActionPerformed

    }//GEN-LAST:event_exercise_tActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        By_days bbd = new By_days();
        bbd.setVisible(true);
    }//GEN-LAST:event_formWindowClosed

    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        this.name_t.setText("");
        this.age_t.setText("");
        this.mobile_t.setText("");
        this.address_t.setText("");
        this.exercise_t.setSelectedIndex(0);
        this.time_t.setSelectedIndex(0);
    }//GEN-LAST:event_cancelActionPerformed

    private void okActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okActionPerformed

        String name, age, mobile, address, exercise, timing;
        name = this.name_t.getText().trim();
        age = this.age_t.getText().trim();
        mobile = this.mobile_t.getText().trim();
        address = this.address_t.getText().trim();
        exercise = String.valueOf(this.exercise_t.getSelectedItem()).trim();
        timing = String.valueOf(this.time_t.getSelectedItem()).trim();
        
        if (name.equals("") || age.equals("") || mobile.equals("") || address.equals("") || exercise.equals("Select")) {
            JOptionPane.showMessageDialog(this, "Something Went Wrong Please Fill all Fields", "Alert", JOptionPane.WARNING_MESSAGE);
            this.name_t.setText("");
            this.age_t.setText("");
            this.mobile_t.setText("");
            this.address_t.setText("");
            this.exercise_t.setSelectedIndex(0);
            this.time_t.setSelectedIndex(0);
        } else {
            try {
                if (Integer.parseInt(age) > 0 && Integer.parseInt(age) < 100) {
                    if (Long.parseLong(mobile) >= 100000000 && Long.parseLong(mobile) <= 99999999999l) {
                        this.name_t.setText("");
                        this.age_t.setText("");
                        this.mobile_t.setText("");
                        this.address_t.setText("");
                        this.exercise_t.setSelectedIndex(0);
                        this.time_t.setSelectedIndex(0);
                        
                        if (i < 5) {
                            if(saturday_day_array[i][4] == null || saturday_day_array[i][4].equals(""))
                            {
                                this.saturday_day_array[i][0]="SA"+String.valueOf(i);
                                this.saturday_day_array[i][1]=name;
                                this.saturday_day_array[i][2]=age;
                                this.saturday_day_array[i][3]=mobile;
                                this.saturday_day_array[i][4]=address;
                                this.saturday_day_array[i][5]=exercise;
                                this.saturday_day_array[i][6]=timing;
                                this.saturday_day_array[i][7]="Saturday";
                                JOptionPane.showMessageDialog(this,"Your Slot Booked Successfully");
                            }
                            i++;
                        } else {
                            JOptionPane.showMessageDialog(this, "All Slocts are booked Please Try again later", "Alert", JOptionPane.WARNING_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Please Enter Proper Mobile Number", "Alert", JOptionPane.WARNING_MESSAGE);
                        this.mobile_t.setText("");
                    }
                } else {
                    this.age_t.setText("");
                    this.mobile_t.setText("");
                    JOptionPane.showMessageDialog(this, "Please Enter correct data in Mobile & age", "Alert", JOptionPane.WARNING_MESSAGE);
                }
            } catch (Exception obj) {
                JOptionPane.showMessageDialog(this, "There is an Problem in your inserted data So pease feed correct data", "Alert", JOptionPane.WARNING_MESSAGE);
                this.name_t.setText("");
                this.age_t.setText("");
                this.mobile_t.setText("");
                this.address_t.setText("");
                this.exercise_t.setSelectedIndex(0);
                this.time_t.setSelectedIndex(0);
            }
        }
    }//GEN-LAST:event_okActionPerformed

    private void name_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_tActionPerformed

    }//GEN-LAST:event_name_tActionPerformed

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
        this.id_t.setText(String.valueOf("SA"+String.valueOf(i)));
    }//GEN-LAST:event_formWindowGainedFocus

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new saturday().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Age;
    private javax.swing.JTextField address_t;
    private javax.swing.JLabel addresss;
    private javax.swing.JTextField age_t;
    private javax.swing.JButton cancel;
    private javax.swing.JLabel exercise;
    private javax.swing.JComboBox<String> exercise_t;
    private javax.swing.JTextField id_t;
    private javax.swing.JLabel idl;
    private javax.swing.JLabel main_heading;
    private javax.swing.JLabel mobile;
    private javax.swing.JTextField mobile_t;
    private javax.swing.JLabel name;
    private javax.swing.JTextField name_t;
    private javax.swing.JButton ok;
    private javax.swing.JComboBox<String> time_t;
    private javax.swing.JLabel timel;
    // End of variables declaration//GEN-END:variables
}
