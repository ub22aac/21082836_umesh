public class By_days extends javax.swing.JFrame {
    public By_days() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sat_schedule = new javax.swing.JButton();
        sun_schedule = new javax.swing.JButton();
        main = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        sat_schedule.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        sat_schedule.setText("1. Saturday Schedules");
        sat_schedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sat_scheduleActionPerformed(evt);
            }
        });

        sun_schedule.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        sun_schedule.setText("2. Sunday Schedules");
        sun_schedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sun_scheduleActionPerformed(evt);
            }
        });

        main.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        main.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        main.setText("Days Appointment");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(sat_schedule, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sun_schedule, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 80, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(main, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(sat_schedule)
                .addGap(40, 40, 40)
                .addComponent(sun_schedule)
                .addGap(40, 40, 40))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void sat_scheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sat_scheduleActionPerformed
        saturday sd = new saturday();
        sd.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_sat_scheduleActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
            Booking_Types bsd = new Booking_Types();
            bsd.setVisible(true);
    }//GEN-LAST:event_formWindowClosed

    private void sun_scheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sun_scheduleActionPerformed
        setVisible(false);
        sunday sd = new sunday();
        sd.setVisible(true);
    }//GEN-LAST:event_sun_scheduleActionPerformed
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new By_days().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel main;
    private javax.swing.JButton sat_schedule;
    private javax.swing.JButton sun_schedule;
    // End of variables declaration//GEN-END:variables
}
