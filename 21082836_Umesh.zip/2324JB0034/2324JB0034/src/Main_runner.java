import javax.swing.JOptionPane;
public class Main_runner extends javax.swing.JFrame { //Main Constructor
    static int allinone=0;

    public Main_runner() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_heading = new javax.swing.JLabel();
        ex_book = new javax.swing.JButton();
        ex_show = new javax.swing.JButton();
        ex_can = new javax.swing.JButton();
        change_bking = new javax.swing.JButton();
        lesson_atmpt = new javax.swing.JButton();
        monthly_rep = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        main_heading.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        main_heading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        main_heading.setText("Main Menu of Weekend Fitness Club");

        ex_book.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        ex_book.setText("A. Book Exercise");
        ex_book.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        ex_book.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ex_bookActionPerformed(evt);
            }
        });

        ex_show.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        ex_show.setText("B. Show Booking");
        ex_show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ex_showActionPerformed(evt);
            }
        });

        ex_can.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        ex_can.setText("C. Cancel Appointment");
        ex_can.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ex_canActionPerformed(evt);
            }
        });

        change_bking.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        change_bking.setText("D. Change Appointment");
        change_bking.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                change_bkingActionPerformed(evt);
            }
        });

        lesson_atmpt.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        lesson_atmpt.setText("E. Attend Appointment");
        lesson_atmpt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lesson_atmptActionPerformed(evt);
            }
        });

        monthly_rep.setFont(new java.awt.Font("SimSun", 0, 18)); // NOI18N
        monthly_rep.setText("F. Monthly Report");
        monthly_rep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthly_repActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_heading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lesson_atmpt, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ex_can, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ex_book, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(100, 316, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(monthly_rep, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(change_bking, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ex_show, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(65, 65, 65))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main_heading, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(ex_book, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(ex_show, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(ex_can, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(change_bking, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(lesson_atmpt, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(monthly_rep, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
     public Integer amount(String exercise) //our function
     {
        int i=0;
        switch(exercise)
        {
            case "YOGA":
                i=70;
            break;
            case "SPIN":
                i=100;
            break;
            case "BODY SCULPT":
                i=90;
            break;
            case "ZUMBA":
                i=50;
            break;
            default:
                i=0;
        }
        return i;
     }
     
    private void ex_bookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ex_bookActionPerformed
        Booking_Types bsd = new Booking_Types();
        bsd.setVisible(true);
    }//GEN-LAST:event_ex_bookActionPerformed

   //==================================================================
   // ------------------ Show -----------------------------------------
   //==================================================================
    
    private void ex_showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ex_showActionPerformed
        String selected = JOptionPane.showInputDialog(this,"i.BY LESSON's\n\nii. BY DAY's\n").trim();
        if(selected.equals("1"))
        {
            String answer = JOptionPane.showInputDialog(this,"Enter ID").trim();
            if(answer.equals("") || answer.length() != 2)
            {
                JOptionPane.showMessageDialog(this,"Please Enter id","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                char st = answer.charAt(0);
                switch(st)
                {
                    case 'B':
                        Exercise_1 e1 = new Exercise_1(); //-------- Body Sculpt
                        e1.set_1(answer);
                    break;
                    case 'S':
                        Exercise_2 e2 = new Exercise_2();
                        e2.set_2(answer);
                    break;
                    case 'Y':
                        Exercise_3 e3 = new Exercise_3();
                        e3.set_3(answer);
                    break;
                    case 'Z':
                        Exercise_4 e4 = new Exercise_4();
                        e4.set_4(answer);
                    break;
                    default:
                        JOptionPane.showMessageDialog(this,"There is no record at this time for Delete","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        else if(selected.equals(null))
        {
            JOptionPane.showMessageDialog(this,"First Enter a Value","Alert",JOptionPane.WARNING_MESSAGE);
        }
        else if(selected.equals("2"))
        {
            String answer11 = JOptionPane.showInputDialog(this,"Enter ID").trim();
            if(answer11.equals("") || answer11.length() != 3)
            {
                JOptionPane.showMessageDialog(this,"Please Enter id","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                char st = answer11.charAt(1);
                switch(st)
                {
                    case 'A':
                        saturday sd = new saturday();
                        sd.set_5(answer11);
                    break;
                    case 'U':
                        sunday su = new sunday();
                        su.set_6(answer11);
                    break;
                    default:
                        JOptionPane.showMessageDialog(this,"There is no record at this time for Delete","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Wrong Value Insert","Alert",JOptionPane.WARNING_MESSAGE);
        }    
    }//GEN-LAST:event_ex_showActionPerformed


   //==================================================================
   // ------------------ Cancel -----------------------------------------
   //==================================================================
    private void ex_canActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ex_canActionPerformed
        String selected = JOptionPane.showInputDialog(this,"i.BY LESSON's\n\nii. BY DAY's\n").trim();
        if(selected.equals("i"))
        {
            String answer = JOptionPane.showInputDialog(this,"Enter ID").trim();
            if(answer.equals("") || answer.length() != 2)
            {
                JOptionPane.showMessageDialog(this,"Please Enter id","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                char st = answer.charAt(0);
                switch(st)
                {
                    case 'B':
                        Exercise_1 e1 = new Exercise_1(); //-------- Body Sculpt
                        e1.set_dlt_1(answer);
                    break;
                    case 'S':
                        Exercise_2 e2 = new Exercise_2();
                        e2.set_dlt_2(answer);
                    break;
                    case 'Y':
                        Exercise_3 e3 = new Exercise_3();
                        e3.set_dlt_3(answer);
                    break;
                    case 'Z':
                        Exercise_4 e4 = new Exercise_4();
                        e4.set_dlt_4(answer);
                    break;
                    default:
                        JOptionPane.showMessageDialog(this,"There is no record at this time for Delete","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        else if(selected.equals(null))
        {
            JOptionPane.showMessageDialog(this,"First Enter a Value","Alert",JOptionPane.WARNING_MESSAGE);
        }
        else if(selected.equals("2"))
        {
            String answer11 = JOptionPane.showInputDialog(this,"Enter ID").trim();
            if(answer11.equals("") || answer11.length() != 3)
            {
                JOptionPane.showMessageDialog(this,"Please Enter id","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                char st = answer11.charAt(1);
                switch(st)
                {
                    case 'A':
                        saturday sd = new saturday();
                        sd.set_dlt_5(answer11);
                    break;
                    case 'U':
                        sunday su = new sunday();
                        su.set_dlt_6(answer11);
                    break;
                    default:
                        JOptionPane.showMessageDialog(this,"There is no record at this time for Delete","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Wrong Value Insert","Alert",JOptionPane.WARNING_MESSAGE);
        }   
    }//GEN-LAST:event_ex_canActionPerformed

    
    
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        
    }//GEN-LAST:event_formWindowClosing

    
   //==================================================================
   // ------------------ Change Booking -------------------------------
   //==================================================================
    private void change_bkingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_change_bkingActionPerformed
        String selected = JOptionPane.showInputDialog(this,"i.BY LESSON's\n\nii. BY DAY's\n").trim();
        if(selected.equals("i"))
        {
            String answer = JOptionPane.showInputDialog(this,"Enter ID").trim();
            if(answer.equals("") || answer.length() != 2)
            {
                JOptionPane.showMessageDialog(this,"Please Enter id","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                char st = answer.charAt(0);
                switch(st)
                {
                    case 'B':
                        Exercise_1 e1 = new Exercise_1(); //-------- Body Sculpt
                        e1.set_change_1(answer);
                    break;
                    case 'S':
                        Exercise_2 e2 = new Exercise_2();
                        e2.set_change_2(answer);
                    break;
                    case 'Y':
                        Exercise_3 e3 = new Exercise_3();
                        e3.set_change_3(answer);
                    break;
                    case 'Z':
                        Exercise_4 e4 = new Exercise_4();
                        e4.set_change_4(answer);
                    break;
                    default:
                        JOptionPane.showMessageDialog(this,"There is no record at this time for Delete","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        else if(selected.equals(null))
        {
            JOptionPane.showMessageDialog(this,"First Enter a Value","Alert",JOptionPane.WARNING_MESSAGE);
        }
        else if(selected.equals("2"))
        {
            String answer11 = JOptionPane.showInputDialog(this,"Enter ID").trim();
            if(answer11.equals("") || answer11.length() != 3)
            {
                JOptionPane.showMessageDialog(this,"Please Enter id","Alert",JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                char st = answer11.charAt(1);
                switch(st)
                {
                    case 'A':
                        saturday sd = new saturday();
                        sd.set_change_5(answer11);
                    break;
                    case 'U':
                        sunday su = new sunday();
                        su.set_change_6(answer11);
                    break;
                    default:
                        JOptionPane.showMessageDialog(this,"There is no record at this time for Delete","Alert",JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Wrong Value Insert","Alert",JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_change_bkingActionPerformed

    
   //==================================================================
   // ------------------ Attend Lesson -------------------------------
   //==================================================================    
    private void lesson_atmptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lesson_atmptActionPerformed
            String a = JOptionPane.showInputDialog(this,"Please Share Us your Experience\n\n1:  Very dissatisfied\n2:  Dissatisfied\n3:  Ok\n4:  Satisfied\n5:  Very Satisfied\nPlease Enter Your Feed Back");
    }//GEN-LAST:event_lesson_atmptActionPerformed

   //==================================================================
   // ------------------ Monthly Report -------------------------------
   //==================================================================
    private void monthly_repActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthly_repActionPerformed
            monthly_report m2 = new monthly_report();
            m2.setVisible(true);
            this.setVisible(false);
    }//GEN-LAST:event_monthly_repActionPerformed
    
    
   //==================================================================
   // ------------------ Main -------------------------------
   //==================================================================
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main_runner().setVisible(true);
              
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton change_bking;
    private javax.swing.JButton ex_book;
    private javax.swing.JButton ex_can;
    private javax.swing.JButton ex_show;
    private javax.swing.JButton lesson_atmpt;
    private javax.swing.JLabel main_heading;
    private javax.swing.JButton monthly_rep;
    // End of variables declaration//GEN-END:variables
}
